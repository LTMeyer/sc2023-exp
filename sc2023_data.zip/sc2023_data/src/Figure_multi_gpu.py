import os
import pandas as pd
import matplotlib.pyplot as plt
import pdb
from cycler import cycler
import numpy as np
import copy
import matplotlib as mpl

column_width_pts = 241.14749
pt_to_inch = 1/72.27
inch_to_cm = 2.54
colum_width = column_width_pts * pt_to_inch

acm_colors = [
    "#ff1924",  # Red
    "#fc9200",  # Orange
    "#0055c9",  # Dark Blue
    "#6200d9",  # Purple
    "#00cf00",  # Green
    "#00fafc",  # Blue
    "#ffd600",  # Yellow
    "#82fcff",  # Light Blue
]

plt.rc("axes", prop_cycle=cycler(color=acm_colors))
plt.rcParams.update({
    "text.usetex": True,
    "font.family": "Libertine",
    "figure.dpi": 300,
    "font.size": 8,
    "axes.titlesize": "medium",
    "axes.labelsize": "medium"

})
w0, h0 = plt.rcParams["figure.figsize"]
plt.rcParams.update({"figure.figsize": [colum_width, h0 * colum_width / w0]})

root_folder = "../data"
batch_folder = "Figure_multigpu_loss"
gpu_folder = "gpu_0"
data_filename = "data.pkl"

value_names = ["val"]  # , "train"]
alpha = [1, 0.2]
lw = [1, 0.2]
lt = ["-", "--"]


def smooth(values, smoothing_factor=0.6):
    smoothed_values = []
    last = values[0]  # .iloc[0]
    for v in values:
        last = last * smoothing_factor + (1 - smoothing_factor) * v
        smoothed_values.append(last)
    return np.array(smoothed_values, dtype=np.float32)


# create a figure
fig, ax = plt.subplots()
df_full = pd.DataFrame()
n = 0
for subdir in os.listdir(os.path.join(root_folder, batch_folder)):
    if "superceded" in subdir:
        continue
    data_path = os.path.join(
        root_folder, batch_folder, subdir, gpu_folder, data_filename)
    print(f"gathering data from {data_path}")
    df = pd.read_pickle(data_path)
    folder_name = subdir

    df.name.replace("Loss/train", "train", inplace=True)
    df.name.replace("Loss/valid", "val", inplace=True)

    if "FIRO" in subdir:
        color = acm_colors[2]
    elif "FIFO" in subdir:
        color = acm_colors[3]
    elif "Reservoir" in subdir:
        color = acm_colors[1]
    elif "Offline" in subdir:
        color = acm_colors[0]

    if "1GPU" in subdir:
        t = "-"
    elif "2GPU" in subdir:
        t = "--"
    elif "4GPU" in subdir:
        t = ":"

    # for each value in the list of values
    for name, a, l, _ in zip(value_names, alpha, lw, lt):
        df_val = copy.deepcopy(df[df.name == name])
        put = copy.deepcopy(df[df.name == "put_time"])
        throughput = copy.deepcopy(df[df.name == "samples_per_second"])
        df_val = df_val.sort_values("step")

        if "Offline" in subdir:
            start = df_val["wall_time"].values[0]
        else:
            start = put["wall_time"].values[0]
        stop = df_val["wall_time"].values[-1]
        wall_time = df_val["wall_time"] - df_val["wall_time"].values[0]
        print(f"plotting for subdir {subdir} with {len(df_val)} values")
        val_loss = df_val["value"].values
        if "Offline" in subdir:
            val_loss = smooth(val_loss, .8)
        ax.plot(df_val["step"], val_loss, t,
                label=folder_name, alpha=a, lw=l, color=color)

        if "val" in name:
            print(f"Total time {(stop - start)/3600}")
            print(f"Minimum RMSE for {subdir} is {df_val['value'].min()})")
            print(f"Mean throughput {throughput['value'].mean()}\n")

    n += 1

# log-scale y-axis
plt.yscale("log")

# add limits to the y-axis
plt.ylim(50, 1e3)
# plt.xlim(0, 1500)

# add labels and legend
plt.xlabel("\# Batch")
plt.ylabel("Loss")
plt.xticks(np.arange(0, 4000, 500))
labels = ["Offline", "FIRO", "Reservoir"]
legend_elements = [mpl.lines.Line2D(
    [0], [0], color=acm_colors[c], label=tag) for c, tag in zip([0, 2, 1], labels)]
legend_elements += [
    mpl.lines.Line2D([0], [0], color="k", linestyle="-", label="1GPU"),
    mpl.lines.Line2D([0], [0], color="k", linestyle="--", label="2GPUs"),
    mpl.lines.Line2D([0], [0], color="k", linestyle=":", label="4GPUs")
]
plt.legend(handles=legend_elements, ncols=2, columnspacing=.5,
           handletextpad=.5, fontsize="small")

fig.tight_layout()
# convert value_names list to string
value_names = "_".join(value_names)
# save the figure in ./figs using the batch_folder name and the value name
fig.savefig(
    f"../figs/{batch_folder}_{value_names.replace('/','_')}.png", bbox_inches="tight")

plt.show()
