# SC2023 experimental data and plotting

This repository contains all the data generated for SC2023 for the paper called "High Throughput Training of Deep Surrogates from Large Ensemble Runs." Additionally, the present repo includes all scripts necessary for processing the data to reproduce the figures available in the paper.

## Running the scripts

The repo contains one script to generate each of the four figures in the paper, including:

- Figure 2: `Figure_2_throughput.py`
- Figure 4: `Figure_4_loss.py`
- Figure 5: `Figure_5_multi_gpu.py`
- Figure 6: `Figure_6_largescale_onlineoffline.py`

To run each script, navigate to `src` and execute:

```bash
cd src
python3 Figure_2_throughput.py
python3 Figure_4_loss.py
python3 Figure_5_multi_gpu.py
python3 Figure_6_largescale_onlineoffline.py
```

These will generate one figure for each script in the directory named `figs`.